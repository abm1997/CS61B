x = 0
while x < 10:
	print(x)
	x = x + 1

x = "horse"
print(x)

print(5 + "horse")