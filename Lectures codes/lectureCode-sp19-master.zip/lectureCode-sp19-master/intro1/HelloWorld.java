public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("hello world");
	}
}

/*
1. All code in Java must be part of a class.
2. We delimit the beginning and end of segments of code
   using { and }.
3. All statements in Java must end in a semi-colon.
4. For code to run we need public static void main(String[] args)
*/