def larger(x, y):
	"""Returns the larger of x and y."""
	if (x > y):
		return x
	return y

print(larger(-5, 10))